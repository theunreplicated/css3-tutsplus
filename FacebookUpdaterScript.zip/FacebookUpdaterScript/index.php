<?php

$api_key = "172578572874666";
$secret = "51e44aa033a4f30a4897a47b3e99faf2";

require_once("facebook.php");
$facebook = new Facebook($api_key,$secret);
$user = $facebook->require_login();
if (!$facebook->api_client->users_hasAppPermission("status_update")){
echo '<fb:prompt-permission perms="status_update" next_fbjs="greet()">Klik disini untuk mengijinkan aplikasi.</fb:prompt-permission>';
$visibility = "none";
}
else
$visibility = "block";

if(isset($_POST['status']))
{
    $facebook->api_client->users_setStatus($_POST['status']);
    echo "<p style='color:green;'>Your Status has been updated successfuly!</p>";
}
?>
<div id="statusdiv" style="display:<?=$visibility;?>;">
    <form method="POST">
        Status Anda?<br/>
        <input type="text" name="status" width="100" /> <br/>
        <input type="submit" value="Update" />
    </form>
</div>

<script>
function greet()
{
    var session = "<?=$facebook->api_client->session_key;?>";
    document.getElementById("statusdiv").setStyle("display","block");
    new Dialog().showMessage("Info","Berhasil! Kini aplikasi sudah terhubung.");
}

</script>
